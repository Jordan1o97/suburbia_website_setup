<?php
/*
Template name: WooCommerce - Checkout
*/

wc_get_template_part('checkout/layouts/checkout', get_theme_mod('checkout_layout'));

?>
